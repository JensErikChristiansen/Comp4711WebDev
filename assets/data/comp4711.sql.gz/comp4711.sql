-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2015 at 09:12 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `comp4711`
--

-- --------------------------------------------------------

--
-- Table structure for table `roster`
--

DROP TABLE IF EXISTS `roster`;
CREATE TABLE IF NOT EXISTS `roster` (
  `ID` int(11) NOT NULL,
  `PlayerNo` int(11) NOT NULL,
  `Name` varchar(22) NOT NULL,
  `Pos` varchar(3) NOT NULL,
  `Status` varchar(3) NOT NULL,
  `Height` varchar(5) NOT NULL,
  `Weight` int(11) NOT NULL,
  `Birthdate` date NOT NULL,
  `Experience` int(11) NOT NULL,
  `College` varchar(19) NOT NULL,
  `Code` varchar(3) NOT NULL,
  `Photo` varchar(100) DEFAULT NULL,
  `PlayerUpdated` varchar(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roster`
--

INSERT INTO `roster` (`ID`, `PlayerNo`, `Name`, `Pos`, `Status`, `Height`, `Weight`, `Birthdate`, `Experience`, `College`, `Code`, `Photo`, `PlayerUpdated`) VALUES
(1, 76, 'Adams, Mike', 'T', 'PUP', '6''7"', 323, '1990-03-10', 4, 'Ohio State', 'PIT', 'Steelers_Mike_Adams_76.jpg', '0'),
(2, 28, 'Allen, Cortez', 'CB', 'RES', '6''1"', 197, '1988-10-29', 5, 'The Citadel', 'PIT', 'Steelers_Cortez_Allen_28.jpg', '0'),
(3, 20, 'Allen, Will', 'SS', 'ACT', '6''1"', 202, '1982-06-17', 12, 'Ohio State', 'PIT', 'Steelers_Will_Allen_20_.jpg', '0'),
(4, 68, 'Beachum, Kelvin', 'T', 'RES', '6''3"', 303, '1989-06-08', 4, 'Southern Methodist', 'PIT', 'Steelers_Kelvin_Beachum_20.jpg', '0'),
(5, 26, 'Bell, Le''Veon', 'RB', 'RES', '6''1"', 244, '1992-02-18', 3, 'Michigan State', 'PIT', 'Steelers_LeVeon_Bell_26.jpg', '0'),
(6, 4, 'Berry, Jordan', 'P', 'ACT', '6''5"', 195, '1991-03-18', 1, 'Eastern Kentucky', 'PIT', 'Steelers_Jordan_Berry_4.jpg', '0'),
(7, 41, 'Blake, Antwon', 'CB', 'ACT', '5''9"', 198, '1990-08-09', 4, 'Texas-El Paso', 'PIT', 'Steelers_Antwon_Blake_41.jpg', '0'),
(8, 87, 'Blanchflower, Rob', 'TE', 'RES', '6''4"', 256, '1990-06-08', 1, 'Massachusetts', 'PIT', 'Steelers_Rob_Blanchflower_87.jpg', '0'),
(9, 6, 'Boswell, Chris', 'K', 'ACT', '6''2"', 185, '1991-03-16', 1, 'Rice', 'PIT', 'Steelers_Chris_Boswell_6.jpg', '0'),
(10, 25, 'Boykin, Brandon', 'DB', 'ACT', '5''10"', 182, '1990-07-13', 4, 'Georgia', 'PIT', 'Steelers_Brandon_Boykin_25.jpg', '0'),
(11, 84, 'Brown, Antonio', 'WR', 'ACT', '5''10"', 181, '1988-07-10', 6, 'Central Michigan', 'PIT', 'Steelers_Antonio_Brown_84.JPG', '0'),
(12, 10, 'Bryant, Martavis', 'WR', 'ACT', '6''4"', 211, '1991-12-20', 2, 'Clemson', 'PIT', 'Steelers_Martavis_Bryant_10.jpg', '0'),
(13, 56, 'Chickillo, Anthony', 'DE', 'ACT', '6''3"', 267, '1992-12-10', 0, 'Miami (Fla.)', 'PIT', 'Steelers_Anthony_Chickillo_56.jpg', '0'),
(14, 14, 'Coates, Sammie', 'WR', 'ACT', '6''1"', 212, '1993-03-31', 0, 'Auburn', 'PIT', 'Steelers_Sammie_Coates_14.jpg', '0'),
(15, 31, 'Cockrell, Ross', 'DB', 'ACT', '6''0"', 191, '1991-08-06', 2, 'Duke', 'PIT', 'Steelers_Ross_Cockrell_31.jpg', '0'),
(16, 66, 'DeCastro, David', 'G', 'ACT', '6''5"', 316, '1990-01-11', 4, 'Stanford', 'PIT', 'Steelers_David_DeCastro_66_.jpg', '0'),
(17, 48, 'Dupree, Bud', 'LB', 'ACT', '6''4"', 269, '1993-02-12', 0, 'Kentucky', 'PIT', 'Steelers_Bud_Dupree_48.jpg', '0'),
(18, 73, 'Foster, Ramon', 'G', 'ACT', '6''5"', 328, '1986-01-07', 7, 'Tennessee', 'PIT', 'Steelers_Ramon_Foster_73.jpg', '0'),
(19, 57, 'Garvin, Terence', 'ILB', 'ACT', '6''2"', 222, '1991-01-01', 3, 'West Virginia', 'PIT', 'Steelers_Terence_Garvin_57.jpg', '0'),
(20, 22, 'Gay, William', 'CB', 'ACT', '5''10"', 187, '1985-01-01', 9, 'Louisville', 'PIT', 'Steelers_William_Gay_22.jpg', '0'),
(21, 96, 'Geathers, Clifton', 'DT', 'RES', '6''8"', 325, '1987-12-11', 6, 'South Carolina', 'PIT', 'Steelers_Clifton_Geathers_96.jpg', '0'),
(22, 77, 'Gilbert, Marcus', 'T', 'ACT', '6''6"', 330, '1988-02-15', 5, 'Florida', 'PIT', 'Steelers_Marcus_Gilbert_77.JPG', '0'),
(23, 21, 'Golden, Robert', 'SS', 'ACT', '5''11"', 202, '1990-09-13', 4, 'Arizona', 'PIT', 'Steelers_Robert_Golden_21.JPG', '0'),
(24, 27, 'Golson, Senquez', 'CB', 'RES', '5''9"', 176, '1993-07-03', 0, 'Mississippi', 'PIT', 'Steelers_Senquez_Golson_27.jpg', '0'),
(25, 5, 'Gradkowski, Bruce', 'QB', 'RES', '6''1"', 220, '1983-01-27', 10, 'Toledo', 'PIT', 'Steelers_Bruce_Gradkowski_5.jpg', '0'),
(26, 24, 'Grant, Doran', 'CB', 'ACT', '5''10"', 200, '1992-11-30', 0, 'Ohio State', 'PIT', 'Steelers_Doran_Grant_24.jpg', '0'),
(27, 92, 'Harrison, James', 'OLB', 'ACT', '6''0"', 242, '1978-05-04', 13, 'Kent State', 'PIT', 'Steelers_Harrison_James_92.jpg', '0'),
(28, 0, 'Hatchie, Micah', 'T', 'RES', '6''5"', 304, '1992-05-15', 0, 'Washington', 'PIT', 'Steelers_Micah_Hatchie.jpg', '0'),
(29, 97, 'Heyward, Cameron', 'DE', 'ACT', '6''5"', 295, '1989-05-06', 5, 'Ohio State', 'PIT', 'Steelers_Cameron_Heyward_95.jpg', '0'),
(30, 88, 'Heyward-Bey, Darrius', 'WR', 'ACT', '6''2"', 210, '1987-02-26', 7, 'Maryland', 'PIT', 'Steelers_Darrius_Heyward-Bey_85.jpg', '0'),
(31, 74, 'Hubbard, Chris', 'G', 'ACT', '6''4"', 295, '1991-04-23', 2, 'Alabama-Birmingham', 'PIT', 'Steelers_Chris_Hubbard_74.jpg', '0'),
(32, 81, 'James, Jesse', 'TE', 'ACT', '6''7"', 261, '1994-06-04', 0, 'Penn State', 'PIT', 'Steelers_Jesse_James_81.jpg', '0'),
(33, 46, 'Johnson, Will', 'FB', 'ACT', '6''2"', 240, '1988-11-14', 4, 'West Virginia', 'PIT', 'Steelers_Will_Johnson_46.jpg', '0'),
(34, 95, 'Jones, Jarvis', 'OLB', 'ACT', '6''3"', 248, '1989-10-13', 3, 'Georgia', 'PIT', 'Steelers_Jarvis_Jones_95.jpg', '0'),
(35, 3, 'Jones, Landry', 'QB', 'ACT', '6''4"', 225, '1989-04-04', 3, 'Oklahoma', 'PIT', 'Steelers_Landry_Jones_3.jpg', '0'),
(36, 12, 'Jones, Jacoby', 'WR', 'ACT', '6''4"', 215, '1984-07-11', 9, 'Lane', 'PIT', 'Steelers_Jacoby_Jones_12.jpg', '0'),
(37, 64, 'Legursky, Doug', 'C', 'ACT', '6''1"', 323, '1986-06-09', 7, 'Marshall', 'PIT', 'Steelers_Doug_Legursky_64.JPG', '0'),
(38, 62, 'McCullers-Sanders, Dan', 'NT', 'ACT', '6''7"', 352, '1992-08-11', 2, 'Tennessee', 'PIT', 'Steelers_Dan_McCullers-Sanders_62.jpg', '0'),
(39, 90, 'McLendon, Steve', 'NT', 'ACT', '6''3"', 310, '1986-01-03', 6, 'Troy', 'PIT', 'Steelers_Steve_McLendon_90_.jpg', '0'),
(40, 83, 'Miller, Heath', 'TE', 'ACT', '6''5"', 256, '1982-10-22', 11, 'Virginia', 'PIT', 'Steelers_Heath_Miller_83.jpg', '0'),
(41, 23, 'Mitchell, Mike', 'FS', 'ACT', '6''1"', 221, '1987-06-10', 7, 'Ohio U.', 'PIT', 'Steelers_Mike_Mitchell_23.jpg', '0'),
(42, 55, 'Moats, Arthur', 'OLB', 'ACT', '6''0"', 246, '1988-03-14', 6, 'James Madison', 'PIT', 'Steelers_Arthur_Moats_55.jpg', '0'),
(43, 15, 'Nelson, David', 'WR', 'RES', '6''5"', 215, '1986-11-07', 6, 'Florida', 'PIT', 'Steelers_David_Nelson_15.jpg', '0'),
(44, 45, 'Nix, Roosevelt', 'FB', 'ACT', '5''11"', 248, '1992-03-30', 1, 'Kent State', 'PIT', 'Steelers_Roosevelt_Nix_45.jpg', '0'),
(45, 69, 'Palmer, Kelvin', 'OT', 'RES', '6''4"', 290, '1990-10-23', 1, 'Baylor', 'PIT', 'Steelers_Kelvin_Palmer_69.jpg', '0'),
(46, 44, 'Pead, Isaiah', 'RB', 'ACT', '5''10"', 204, '1989-12-14', 4, 'Cincinnati', 'PIT', 'Steelers_Isaiah_Pead_44.jpg', '0'),
(47, 53, 'Pouncey, Maurkice', 'C', 'RES', '6''4"', 304, '1989-07-24', 6, 'Florida', 'PIT', 'Steelers_Maurkice_Pouncey_53.jpg', '0'),
(48, 7, 'Roethlisberger, Ben', 'QB', 'ACT', '6''5"', 240, '1982-03-02', 12, 'Miami (Ohio)', 'PIT', 'Steelers_Ben_Roethlisberger_7.jpg', '0'),
(49, 0, 'Rogers, Eli', 'WR', 'RES', '5''10"', 180, '1992-12-23', 0, 'Louisville', 'PIT', 'Steelers_Eli_Rogers.jpg', '0'),
(50, 50, 'Shazier, Ryan', 'ILB', 'ACT', '6''1"', 230, '1992-09-06', 2, 'Ohio State', 'PIT', 'Steelers_Ryan_Shazier_50.jpg', '0'),
(51, 89, 'Spaeth, Matt', 'TE', 'ACT', '6''7"', 262, '1983-11-24', 9, 'Minnesota', 'PIT', 'Steelers_Matt_Spaeth_89.jpg', '0'),
(52, 51, 'Spence, Sean', 'ILB', 'ACT', '5''11"', 231, '1990-06-07', 4, 'Miami (Fla.)', 'PIT', 'Steelers_Sean_Spence_51.jpg', '0'),
(53, 68, 'Stingily, Byron', 'T', 'ACT', '6''5"', 318, '1988-09-09', 5, 'Louisville', 'PIT', 'Steelers_Byron_Stingily_68.jpg', '0'),
(54, 6, 'Suisham, Shaun', 'K', 'RES', '6''0"', 200, '1981-12-29', 11, 'Bowling Green State', 'PIT', 'Steelers_Shaun_Suisham_6.jpg', '0'),
(55, 93, 'Thomas, Cam', 'DE', 'ACT', '6''4"', 335, '1986-12-12', 6, 'North Carolina', 'PIT', 'Steelers_Cam_Thomas_93.jpg', '0'),
(56, 29, 'Thomas, Shamarko', 'SS', 'ACT', '5''9"', 205, '1991-02-23', 3, 'Syracuse', 'PIT', 'Steelers_Shamarko_Thomas_29.jpg', '0'),
(57, 94, 'Timmons, Lawrence', 'ILB', 'ACT', '6''1"', 234, '1986-05-14', 9, 'Florida State', 'PIT', 'Steelers_Lawrence_Timmons_94.jpg', '0'),
(58, 30, 'Todman, Jordan', 'RB', 'ACT', '5''9"', 203, '1990-02-24', 4, 'Connecticut', 'PIT', 'Steelers_Jordan_Todman_30.jpg', '0'),
(59, 91, 'Tuitt, Stephon', 'DE', 'ACT', '6''6"', 303, '1993-05-23', 2, 'Notre Dame', 'PIT', 'Steelers_Stephon_Tuitt_91.jpg', '0'),
(60, 64, 'Van Dyk, Mitchell', 'T', 'RES', '6''7"', 299, '1991-01-02', 1, 'Portland State', 'PIT', 'Steelers_Mitchell_VanDyk_64.jpg', '0'),
(61, 2, 'Vick, Mike', 'QB', 'ACT', '6''0"', 210, '1980-06-26', 15, 'Virginia Tech', 'PIT', 'Steelers_Mike_Vick_2.jpg', '0'),
(62, 78, 'Villanueva, Alejandro', 'T', 'ACT', '6''9"', 320, '1988-09-22', 1, 'Army', 'PIT', 'Steelers_Alejandro_Villanueva_78.jpg', '0'),
(63, 72, 'Wallace, Cody', 'C', 'ACT', '6''4"', 296, '1984-11-26', 6, 'Texas A&M', 'PIT', 'Steelers_Cody_Wallace_72.jpg', '0'),
(64, 96, 'Walton, L.T.', 'DT', 'ACT', '6''5"', 305, '1992-03-31', 0, 'Central Michigan', 'PIT', 'Steelers_LT_Walton_96.jpg', '0'),
(65, 60, 'Warren, Greg', 'LS', 'ACT', '6''3"', 252, '1981-10-18', 11, 'North Carolina', 'PIT', 'Steelers_Greg_Warren_60.jpg', '0'),
(66, 11, 'Wheaton, Markus', 'WR', 'ACT', '5''11"', 189, '1991-02-07', 3, 'Oregon State', 'PIT', 'Steelers_Markus_Wheaton_11.jpg', '0'),
(67, 34, 'Williams, DeAngelo', 'RB', 'ACT', '5''9"', 207, '1983-04-25', 10, 'Memphis', 'PIT', 'Steelers_DeAngelo_Williams_34.jpg', '0'),
(68, 98, 'Williams, Vince', 'ILB', 'ACT', '6''1"', 253, '1989-12-27', 3, 'Florida State', 'PIT', 'Steelers_Vince_Williams_98.jpg', '0'),
(69, 56, 'Zumwalt, Jordan', 'OLB', 'RES', '6''4"', 235, '1991-10-13', 2, 'UCLA', 'PIT', 'Steelers_Jordan_Zumwalt_56.jpg', '0');

-- --------------------------------------------------------

--
-- Table structure for table `scores`
--

DROP TABLE IF EXISTS `scores`;
CREATE TABLE IF NOT EXISTS `scores` (
  `ID` int(11) NOT NULL,
  `Code` varchar(3) NOT NULL,
  `Date` date NOT NULL,
  `ScoreHome` int(11) NOT NULL,
  `OpponentCode` varchar(3) NOT NULL,
  `ScoreOpponent` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `standings`
--

DROP TABLE IF EXISTS `standings`;
CREATE TABLE IF NOT EXISTS `standings` (
  `ID` int(11) NOT NULL,
  `Code` varchar(3) DEFAULT NULL,
  `TeamName` varchar(20) DEFAULT NULL,
  `W` int(11) DEFAULT NULL,
  `L` int(11) DEFAULT NULL,
  `T` bit(1) DEFAULT NULL,
  `Pct1` decimal(5,3) DEFAULT NULL,
  `PF` int(11) DEFAULT NULL,
  `PA` int(11) DEFAULT NULL,
  `Net_Pts` int(11) DEFAULT NULL,
  `TD` int(11) DEFAULT NULL,
  `Home` varchar(3) DEFAULT NULL,
  `Road` varchar(3) DEFAULT NULL,
  `Division` varchar(3) DEFAULT NULL,
  `Pct2` decimal(5,3) DEFAULT NULL,
  `Conf` varchar(3) DEFAULT NULL,
  `Pct3` decimal(5,3) DEFAULT NULL,
  `NonConf` varchar(3) DEFAULT NULL,
  `Streak` varchar(2) DEFAULT NULL,
  `Last_5` varchar(3) DEFAULT NULL,
  `League` varchar(14) DEFAULT NULL,
  `AreaSeason` varchar(50) DEFAULT NULL,
  `TeamLogo` varchar(100) NOT NULL,
  `SiteURL` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `standings`
--

INSERT INTO `standings` (`ID`, `Code`, `TeamName`, `W`, `L`, `T`, `Pct1`, `PF`, `PA`, `Net_Pts`, `TD`, `Home`, `Road`, `Division`, `Pct2`, `Conf`, `Pct3`, `NonConf`, `Streak`, `Last_5`, `League`, `AreaSeason`, `TeamLogo`, `SiteURL`) VALUES
(1, 'NE', 'New England Patriots', 8, 0, b'0', '1.000', 276, 143, 133, 31, '5-0', '3-0', '3-0', '1.000', '6-0', '1.000', '2-0', '8W', '5-0', 'AFC East Team', 'American Football Conference - 2015 Regular Season', 'patriots.jpg', ''),
(2, 'BUF', 'Buffalo Bills', 5, 4, b'0', '0.556', 231, 207, 24, 28, '2-3', '3-1', '3-1', '0.750', '5-3', '0.625', '0-1', '2W', '3-2', 'AFC East Team', 'American Football Conference - 2015 Regular Season', 'buffalos.jpg', ''),
(3, 'NYJ', 'New York Jets', 5, 4, b'0', '0.556', 217, 184, 33, 25, '3-2', '2-2', '1-2', '0.333', '4-3', '0.571', '1-1', '1L', '2-3', 'AFC East Team', 'American Football Conference - 2015 Regular Season', 'jets.jpg', ''),
(4, 'MIA', 'Miami Dolphins', 3, 5, b'0', '0.375', 171, 206, -35, 22, '1-2', '2-3', '0-4', '0.000', '2-5', '0.286', '1-0', '2L', '2-3', 'AFC East Team', 'American Football Conference - 2015 Regular Season', 'dolphins.jpg', ''),
(5, 'CIN', 'Cincinnati Bengals', 8, 0, b'0', '1.000', 229, 142, 87, 28, '4-0', '4-0', '3-0', '1.000', '7-0', '1.000', '1-0', '8W', '5-0', 'AFC North Team', 'American Football Conference - 2015 Regular Season', 'bengals.jpg', ''),
(6, 'PIT', 'Pittsburgh Steelers', 5, 4, b'0', '0.556', 206, 182, 24, 22, '3-2', '2-2', '0-2', '0.000', '2-4', '0.333', '3-0', '1W', '3-2', 'AFC North Team', 'American Football Conference - 2015 Regular Season', 'steelers.jpg', '/roster'),
(7, 'BAL', 'Baltimore Ravens', 2, 6, b'0', '0.250', 190, 214, -24, 19, '1-2', '1-4', '1-2', '0.333', '2-4', '0.333', '0-2', '1W', '2-3', 'AFC North Team', 'American Football Conference - 2015 Regular Season', 'ravens.jpg', ''),
(8, 'CLE', 'Cleveland Browns', 2, 7, b'0', '0.222', 177, 247, -70, 19, '1-3', '1-4', '1-1', '0.500', '2-5', '0.286', '0-2', '4L', '1-4', 'AFC North Team', 'American Football Conference - 2015 Regular Season', 'browns.jpg', ''),
(9, 'IND', 'Indianapolis Colts', 4, 5, b'0', '0.444', 200, 227, -27, 24, '2-3', '2-2', '3-0', '1.000', '4-3', '0.571', '0-2', '1W', '2-3', 'AFC South Team', 'American Football Conference - 2015 Regular Season', 'colts.jpg', ''),
(10, 'HOU', 'Houston Texans', 3, 5, b'0', '0.375', 174, 205, -31, 21, '2-2', '1-3', '2-1', '0.667', '2-3', '0.400', '1-2', '1W', '2-3', 'AFC South Team', 'American Football Conference - 2015 Regular Season', 'texans.jpg', ''),
(11, 'JAC', 'Jacksonville Jaguars', 2, 6, b'0', '0.250', 170, 235, -65, 20, '2-2', '0-4', '0-2', '0.000', '2-4', '0.333', '0-2', '1L', '1-4', 'AFC South Team', 'American Football Conference - 2015 Regular Season', 'jaguars.jpg', ''),
(12, 'TEN', 'Tennessee Titans', 2, 6, b'0', '0.250', 159, 187, -28, 19, '0-4', '2-2', '0-2', '0.000', '0-5', '0.000', '2-1', '1W', '1-4', 'AFC South Team', 'American Football Conference - 2015 Regular Season', 'titans.jpg', ''),
(13, 'DEN', 'Denver Broncos', 7, 1, b'0', '0.875', 192, 139, 53, 19, '3-0', '4-1', '2-0', '1.000', '4-1', '0.800', '3-0', '1L', '4-1', 'AFC West Team', 'American Football Conference - 2015 Regular Season', 'broncos.jpg', ''),
(14, 'OAK', 'Oakland Raiders', 4, 4, b'0', '0.500', 213, 211, 2, 25, '2-2', '2-2', '1-1', '0.500', '4-3', '0.571', '0-1', '1L', '2-3', 'AFC West Team', 'American Football Conference - 2015 Regular Season', 'raiders.jpg', ''),
(15, 'KCC', 'Kansas City Chiefs', 3, 5, b'0', '0.375', 195, 182, 13, 21, '2-2', '1-3', '0-1', '0.000', '2-2', '0.500', '1-3', '2W', '2-3', 'AFC West Team', 'American Football Conference - 2015 Regular Season', 'chiefs.jpg', ''),
(16, 'SDC', 'San Diego Chargers', 2, 7, b'0', '0.222', 210, 249, -39, 23, '2-3', '0-4', '0-1', '0.000', '1-4', '0.200', '1-3', '5L', '0-5', 'AFC West Team', 'American Football Conference - 2015 Regular Season', 'chargers.jpg', ''),
(17, 'NYG', 'New York Giants', 5, 4, b'0', '0.556', 247, 226, 21, 27, '3-1', '2-3', '2-2', '0.500', '4-4', '0.500', '1-0', '1W', '3-2', 'NFC East Team', 'National Football Conference - 2015 Regular Season', 'giants.jpg', ''),
(18, 'PHI', 'Philadelphia Eagles', 4, 4, b'0', '0.500', 193, 164, 29, 22, '2-1', '2-3', '2-2', '0.500', '3-4', '0.429', '1-0', '1W', '3-2', 'NFC East Team', 'National Football Conference - 2015 Regular Season', 'eagles.jpg', ''),
(19, 'WAS', 'Washington Redskins', 3, 5, b'0', '0.375', 158, 195, -37, 17, '3-1', '0-4', '1-1', '0.500', '3-2', '0.600', '0-3', '1L', '2-3', 'NFC East Team', 'National Football Conference - 2015 Regular Season', 'redskins.jpg', ''),
(20, 'DAL', 'Dallas Cowboys', 2, 6, b'0', '0.250', 160, 204, -44, 16, '1-4', '1-2', '2-2', '0.500', '2-5', '0.286', '0-1', '6L', '0-5', 'NFC East Team', 'National Football Conference - 2015 Regular Season', 'cowboys.jpg', ''),
(21, 'GBP', 'Green Bay Packers', 6, 2, b'0', '0.750', 203, 167, 36, 24, '4-0', '2-2', '1-0', '1.000', '4-1', '0.800', '2-1', '2L', '3-2', 'NFC North Team', 'National Football Conference - 2015 Regular Season', 'packers.jpg', ''),
(22, 'MIN', 'Minnesota Vikings', 6, 2, b'0', '0.750', 168, 140, 28, 16, '4-0', '2-2', '3-0', '1.000', '4-1', '0.800', '2-1', '4W', '4-1', 'NFC North Team', 'National Football Conference - 2015 Regular Season', 'vikings.jpg', ''),
(23, 'CHI', 'Chicago Bears', 3, 5, b'0', '0.375', 162, 221, -59, 16, '1-3', '2-2', '0-3', '0.000', '0-5', '0.000', '3-0', '1W', '3-2', 'NFC North Team', 'National Football Conference - 2015 Regular Season', 'bears.jpg', ''),
(24, 'DET', 'Detroit Lions', 1, 7, b'0', '0.125', 149, 245, -96, 18, '1-3', '0-4', '1-2', '0.333', '1-4', '0.200', '0-3', '2L', '1-4', 'NFC North Team', 'National Football Conference - 2015 Regular Season', 'lions.jpg', ''),
(25, 'CAR', 'Carolina Panthers', 8, 0, b'0', '1.000', 228, 165, 63, 26, '5-0', '3-0', '2-0', '1.000', '5-0', '1.000', '3-0', '8W', '5-0', 'NFC South Team', 'National Football Conference - 2015 Regular Season', 'panthers.jpg', ''),
(26, 'ATL', 'Atlanta Falcons', 6, 3, b'0', '0.667', 229, 190, 39, 27, '3-1', '3-2', '0-2', '0.000', '4-3', '0.571', '2-0', '2L', '2-3', 'NFC South Team', 'National Football Conference - 2015 Regular Season', 'falcons.jpg', ''),
(27, 'NOS', 'New Orleans Saints', 4, 5, b'0', '0.444', 241, 268, -27, 31, '3-2', '1-3', '1-2', '0.333', '3-4', '0.429', '1-1', '1L', '3-2', 'NFC South Team', 'National Football Conference - 2015 Regular Season', 'saints.jpg', ''),
(28, 'TBB', 'Tampa Bay Buccaneers', 3, 5, b'0', '0.375', 181, 231, -50, 18, '1-3', '2-2', '2-1', '0.667', '2-3', '0.400', '1-2', '1L', '2-3', 'NFC South Team', 'National Football Conference - 2015 Regular Season', 'buccaneers.jpg', ''),
(29, 'ARI', 'Arizona Cardinals', 6, 2, b'0', '0.750', 263, 153, 110, 32, '3-1', '3-1', '1-1', '0.500', '4-1', '0.800', '2-1', '2W', '3-2', 'NFC West Team', 'National Football Conference - 2015 Regular Season', 'cardinals.jpg', ''),
(30, 'SLR', 'St. Louis Rams', 4, 4, b'0', '0.500', 153, 146, 7, 16, '3-1', '1-3', '3-0', '1.000', '3-3', '0.500', '1-1', '1L', '3-2', 'NFC West Team', 'National Football Conference - 2015 Regular Season', 'rams.jpg', ''),
(31, 'SEA', 'Seattle Seahawks', 4, 4, b'0', '0.500', 167, 140, 27, 16, '2-1', '2-3', '1-1', '0.500', '4-3', '0.571', '0-1', '2W', '3-2', 'NFC West Team', 'National Football Conference - 2015 Regular Season', 'seahawks.jpg', ''),
(32, 'SF', 'San Francisco 49ers', 3, 6, b'0', '0.333', 126, 223, -97, 12, '3-2', '0-4', '0-3', '0.000', '2-5', '0.286', '1-1', '1W', '2-3', 'NFC West Team', 'National Football Conference - 2015 Regular Season', '49ers.jpg', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `roster`
--
ALTER TABLE `roster`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Code` (`Code`);

--
-- Indexes for table `scores`
--
ALTER TABLE `scores`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `standings`
--
ALTER TABLE `standings`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Code` (`Code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `roster`
--
ALTER TABLE `roster`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=70;
--
-- AUTO_INCREMENT for table `scores`
--
ALTER TABLE `scores`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `standings`
--
ALTER TABLE `standings`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `roster`
--
ALTER TABLE `roster`
  ADD CONSTRAINT `FK_Code` FOREIGN KEY (`Code`) REFERENCES `standings` (`Code`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
