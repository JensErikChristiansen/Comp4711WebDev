-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2015 at 10:22 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `comp4711`
--

-- --------------------------------------------------------

--
-- Table structure for table `roster`
--

DROP TABLE IF EXISTS `roster`;
CREATE TABLE IF NOT EXISTS `roster` (
  `ID` int(11) NOT NULL,
  `PlayerNo` int(11) NOT NULL,
  `Name` varchar(22) NOT NULL,
  `Pos` varchar(3) NOT NULL,
  `Status` varchar(3) NOT NULL,
  `Height` varchar(5) NOT NULL,
  `Weight` int(11) NOT NULL,
  `Birthdate` date NOT NULL,
  `Experience` int(11) NOT NULL,
  `College` varchar(19) NOT NULL,
  `Code` varchar(3) NOT NULL,
  `Photo` varchar(100) DEFAULT NULL,
  `PlayerUpdated` varchar(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roster`
--

INSERT INTO `roster` (`ID`, `PlayerNo`, `Name`, `Pos`, `Status`, `Height`, `Weight`, `Birthdate`, `Experience`, `College`, `Code`, `Photo`, `PlayerUpdated`) VALUES
(1, 76, 'Adams, Mike', 'T', 'PUP', '6''7"', 323, '1990-03-10', 4, 'Ohio State', 'PIT', 'Steelers_Mike_Adams_76.jpg', 'e'),
(2, 28, 'Allen, Cortez', 'CB', 'RES', '6''1"', 197, '1988-10-29', 5, 'The Citadel', 'PIT', 'Steelers_Cortez_Allen_28.jpg', '0'),
(3, 20, 'Allen, Will', 'SS', 'ACT', '6''1"', 202, '1982-06-17', 12, 'Ohio State', 'PIT', 'Steelers_Will_Allen_20_.jpg', '0'),
(4, 68, 'Beachum, Kelvin', 'T', 'RES', '6''3"', 303, '1989-06-08', 4, 'Southern Methodist', 'PIT', 'Steelers_Kelvin_Beachum_20.jpg', '0'),
(5, 26, 'Bell, Le''Veon', 'RB', 'RES', '6''1"', 244, '1992-02-18', 3, 'Michigan State', 'PIT', 'Steelers_LeVeon_Bell_26.jpg', '0'),
(6, 4, 'Berry, Jordan', 'P', 'ACT', '6''5"', 195, '1991-03-18', 1, 'Eastern Kentucky', 'PIT', 'Steelers_Jordan_Berry_4.jpg', '0'),
(7, 41, 'Blake, Antwon', 'CB', 'ACT', '5''9"', 198, '1990-08-09', 4, 'Texas-El Paso', 'PIT', 'Steelers_Antwon_Blake_41.jpg', '0'),
(8, 87, 'Blanchflower, Rob', 'TE', 'RES', '6''4"', 256, '1990-06-08', 1, 'Massachusetts', 'PIT', 'Steelers_Rob_Blanchflower_87.jpg', '0'),
(9, 9, 'Boswell, Chris', 'K', 'ACT', '6''2"', 185, '1991-03-16', 1, 'Rice', 'PIT', 'Steelers_Chris_Boswell_6.jpg', '0'),
(10, 25, 'Boykin, Brandon', 'DB', 'ACT', '5''10"', 182, '1990-07-13', 4, 'Georgia', 'PIT', 'Steelers_Brandon_Boykin_25.jpg', '0'),
(11, 84, 'Brown, Antonio', 'WR', 'ACT', '5''10"', 181, '1988-07-10', 6, 'Central Michigan', 'PIT', 'Steelers_Antonio_Brown_84.JPG', '0'),
(12, 10, 'Bryant, Martavis', 'WR', 'ACT', '6''4"', 211, '1991-12-20', 2, 'Clemson', 'PIT', 'Steelers_Martavis_Bryant_10.jpg', '0'),
(13, 56, 'Chickillo, Anthony', 'DE', 'ACT', '6''3"', 267, '1992-12-10', 0, 'Miami (Fla.)', 'PIT', 'Steelers_Anthony_Chickillo_56.jpg', '0'),
(14, 14, 'Coates, Sammie', 'WR', 'ACT', '6''1"', 212, '1993-03-31', 0, 'Auburn', 'PIT', 'Steelers_Sammie_Coates_14.jpg', '0'),
(15, 31, 'Cockrell, Ross', 'DB', 'ACT', '6''0"', 191, '1991-08-06', 2, 'Duke', 'PIT', 'Steelers_Ross_Cockrell_31.jpg', '0'),
(16, 66, 'DeCastro, David', 'G', 'ACT', '6''5"', 316, '1990-01-11', 4, 'Stanford', 'PIT', 'Steelers_David_DeCastro_66_.jpg', '0'),
(17, 48, 'Dupree, Bud', 'LB', 'ACT', '6''4"', 269, '1993-02-12', 0, 'Kentucky', 'PIT', 'Steelers_Bud_Dupree_48.jpg', '0'),
(18, 73, 'Foster, Ramon', 'G', 'ACT', '6''5"', 328, '1986-01-07', 7, 'Tennessee', 'PIT', 'Steelers_Ramon_Foster_73.jpg', '0'),
(19, 57, 'Garvin, Terence', 'ILB', 'ACT', '6''2"', 222, '1991-01-01', 3, 'West Virginia', 'PIT', 'Steelers_Terence_Garvin_57.jpg', '0'),
(20, 22, 'Gay, William', 'CB', 'ACT', '5''10"', 187, '1985-01-01', 9, 'Louisville', 'PIT', 'Steelers_William_Gay_22.jpg', '0'),
(21, 96, 'Geathers, Clifton', 'DT', 'RES', '6''8"', 325, '1987-12-11', 6, 'South Carolina', 'PIT', 'Steelers_Clifton_Geathers_96.jpg', '0'),
(22, 77, 'Gilbert, Marcus', 'T', 'ACT', '6''6"', 330, '1988-02-15', 5, 'Florida', 'PIT', 'Steelers_Marcus_Gilbert_77.JPG', '0'),
(23, 21, 'Golden, Robert', 'SS', 'ACT', '5''11"', 202, '1990-09-13', 4, 'Arizona', 'PIT', 'Steelers_Robert_Golden_21.JPG', '0'),
(24, 27, 'Golson, Senquez', 'CB', 'RES', '5''9"', 176, '1993-07-03', 0, 'Mississippi', 'PIT', 'Steelers_Senquez_Golson_27.jpg', '0'),
(25, 5, 'Gradkowski, Bruce', 'QB', 'RES', '6''1"', 220, '1983-01-27', 10, 'Toledo', 'PIT', 'Steelers_Bruce_Gradkowski_5.jpg', '0'),
(26, 24, 'Grant, Doran', 'CB', 'ACT', '5''10"', 200, '1992-11-30', 0, 'Ohio State', 'PIT', 'Steelers_Doran_Grant_24.jpg', '0'),
(27, 92, 'Harrison, James', 'OLB', 'ACT', '6''0"', 242, '1978-05-04', 13, 'Kent State', 'PIT', 'Steelers_Harrison_James_92.jpg', '0'),
(28, 0, 'Hatchie, Micah', 'T', 'RES', '6''5"', 304, '1992-05-15', 0, 'Washington', 'PIT', 'Steelers_Micah_Hatchie.jpg', '0'),
(29, 97, 'Heyward, Cameron', 'DE', 'ACT', '6''5"', 295, '1989-05-06', 5, 'Ohio State', 'PIT', 'Steelers_Cameron_Heyward_95.jpg', '0'),
(30, 88, 'Heyward-Bey, Darrius', 'WR', 'ACT', '6''2"', 210, '1987-02-26', 7, 'Maryland', 'PIT', 'Steelers_Darrius_Heyward-Bey_85.jpg', '0'),
(31, 74, 'Hubbard, Chris', 'G', 'ACT', '6''4"', 295, '1991-04-23', 2, 'Alabama-Birmingham', 'PIT', 'Steelers_Chris_Hubbard_74.jpg', '0'),
(32, 81, 'James, Jesse', 'TE', 'ACT', '6''7"', 261, '1994-06-04', 0, 'Penn State', 'PIT', 'Steelers_Jesse_James_81.jpg', '0'),
(33, 46, 'Johnson, Will', 'FB', 'ACT', '6''2"', 240, '1988-11-14', 4, 'West Virginia', 'PIT', 'Steelers_Will_Johnson_46.jpg', '0'),
(34, 95, 'Jones, Jarvis', 'OLB', 'ACT', '6''3"', 248, '1989-10-13', 3, 'Georgia', 'PIT', 'Steelers_Jarvis_Jones_95.jpg', '0'),
(35, 3, 'Jones, Landry', 'QB', 'ACT', '6''4"', 225, '1989-04-04', 3, 'Oklahoma', 'PIT', 'Steelers_Landry_Jones_3.jpg', '0'),
(36, 12, 'Jones, Jacoby', 'WR', 'ACT', '6''4"', 215, '1984-07-11', 9, 'Lane', 'PIT', 'Steelers_Jacoby_Jones_12.jpg', '0'),
(37, 64, 'Legursky, Doug', 'C', 'ACT', '6''1"', 323, '1986-06-09', 7, 'Marshall', 'PIT', 'Steelers_Doug_Legursky_64.JPG', '0'),
(38, 62, 'McCullers-Sanders, Dan', 'NT', 'ACT', '6''7"', 352, '1992-08-11', 2, 'Tennessee', 'PIT', 'Steelers_Dan_McCullers-Sanders_62.jpg', '0'),
(39, 90, 'McLendon, Steve', 'NT', 'ACT', '6''3"', 310, '1986-01-03', 6, 'Troy', 'PIT', 'Steelers_Steve_McLendon_90_.jpg', '0'),
(40, 83, 'Miller, Heath', 'TE', 'ACT', '6''5"', 256, '1982-10-22', 11, 'Virginia', 'PIT', 'Steelers_Heath_Miller_83.jpg', '0'),
(41, 23, 'Mitchell, Mike', 'FS', 'ACT', '6''1"', 221, '1987-06-10', 7, 'Ohio U.', 'PIT', 'Steelers_Mike_Mitchell_23.jpg', '0'),
(42, 55, 'Moats, Arthur', 'OLB', 'ACT', '6''0"', 246, '1988-03-14', 6, 'James Madison', 'PIT', 'Steelers_Arthur_Moats_55.jpg', '0'),
(43, 15, 'Nelson, David', 'WR', 'RES', '6''5"', 215, '1986-11-07', 6, 'Florida', 'PIT', 'Steelers_David_Nelson_15.jpg', '0'),
(44, 45, 'Nix, Roosevelt', 'FB', 'ACT', '5''11"', 248, '1992-03-30', 1, 'Kent State', 'PIT', 'Steelers_Roosevelt_Nix_45.jpg', '0'),
(45, 69, 'Palmer, Kelvin', 'OT', 'RES', '6''4"', 290, '1990-10-23', 1, 'Baylor', 'PIT', 'Steelers_Kelvin_Palmer_69.jpg', '0'),
(46, 44, 'Pead, Isaiah', 'RB', 'ACT', '5''10"', 204, '1989-12-14', 4, 'Cincinnati', 'PIT', 'Steelers_Isaiah_Pead_44.jpg', '0'),
(47, 53, 'Pouncey, Maurkice', 'C', 'RES', '6''4"', 304, '1989-07-24', 6, 'Florida', 'PIT', 'Steelers_Maurkice_Pouncey_53.jpg', '0'),
(48, 7, 'Roethlisberger, Ben', 'QB', 'ACT', '6''5"', 240, '1982-03-02', 12, 'Miami (Ohio)', 'PIT', 'Steelers_Ben_Roethlisberger_7.jpg', '0'),
(49, 0, 'Rogers, Eli', 'WR', 'RES', '5''10"', 180, '1992-12-23', 0, 'Louisville', 'PIT', 'Steelers_Eli_Rogers.jpg', 'e'),
(50, 50, 'Shazier, Ryan', 'ILB', 'ACT', '6''1"', 230, '1992-09-06', 2, 'Ohio State', 'PIT', 'Steelers_Ryan_Shazier_50.jpg', '0'),
(51, 89, 'Spaeth, Matt', 'TE', 'ACT', '6''7"', 262, '1983-11-24', 9, 'Minnesota', 'PIT', 'Steelers_Matt_Spaeth_89.jpg', '0'),
(52, 51, 'Spence, Sean', 'ILB', 'ACT', '5''11"', 231, '1990-06-07', 4, 'Miami (Fla.)', 'PIT', 'Steelers_Sean_Spence_51.jpg', '0'),
(53, 68, 'Stingily, Byron', 'T', 'ACT', '6''5"', 318, '1988-09-09', 5, 'Louisville', 'PIT', 'Steelers_Byron_Stingily_68.jpg', '0'),
(54, 6, 'Suisham, Shaun', 'K', 'RES', '6''0"', 200, '1981-12-29', 11, 'Bowling Green State', 'PIT', 'Steelers_Shaun_Suisham_6.jpg', '0'),
(55, 93, 'Thomas, Cam', 'DE', 'ACT', '6''4"', 335, '1986-12-12', 6, 'North Carolina', 'PIT', 'Steelers_Cam_Thomas_93.jpg', '0'),
(56, 29, 'Thomas, Shamarko', 'SS', 'ACT', '5''9"', 205, '1991-02-23', 3, 'Syracuse', 'PIT', 'Steelers_Shamarko_Thomas_29.jpg', '0'),
(57, 94, 'Timmons, Lawrence', 'ILB', 'ACT', '6''1"', 234, '1986-05-14', 9, 'Florida State', 'PIT', 'Steelers_Lawrence_Timmons_94.jpg', '0'),
(58, 30, 'Todman, Jordan', 'RB', 'ACT', '5''9"', 203, '1990-02-24', 4, 'Connecticut', 'PIT', 'Steelers_Jordan_Todman_30.jpg', '0'),
(59, 91, 'Tuitt, Stephon', 'DE', 'ACT', '6''6"', 303, '1993-05-23', 2, 'Notre Dame', 'PIT', 'Steelers_Stephon_Tuitt_91.jpg', '0'),
(60, 64, 'Van Dyk, Mitchell', 'T', 'RES', '6''7"', 299, '1991-01-02', 1, 'Portland State', 'PIT', 'Steelers_Mitchell_VanDyk_64.jpg', '0'),
(61, 2, 'Vick, Mike', 'QB', 'ACT', '6''0"', 210, '1980-06-26', 15, 'Virginia Tech', 'PIT', 'Steelers_Mike_Vick_2.jpg', '0'),
(62, 78, 'Villanueva, Alejandro', 'T', 'ACT', '6''9"', 320, '1988-09-22', 1, 'Army', 'PIT', 'Steelers_Alejandro_Villanueva_78.jpg', '0'),
(63, 72, 'Wallace, Cody', 'C', 'ACT', '6''4"', 296, '1984-11-26', 6, 'Texas A&M', 'PIT', 'Steelers_Cody_Wallace_72.jpg', '0'),
(64, 96, 'Walton, L.T.', 'DT', 'ACT', '6''5"', 305, '1992-03-31', 0, 'Central Michigan', 'PIT', 'Steelers_LT_Walton_96.jpg', '0'),
(65, 60, 'Warren, Greg', 'LS', 'ACT', '6''3"', 252, '1981-10-18', 11, 'North Carolina', 'PIT', 'Steelers_Greg_Warren_60.jpg', '0'),
(66, 11, 'Wheaton, Markus', 'WR', 'ACT', '5''11"', 189, '1991-02-07', 3, 'Oregon State', 'PIT', 'Steelers_Markus_Wheaton_11.jpg', '0'),
(67, 34, 'Williams, DeAngelo', 'RB', 'ACT', '5''9"', 207, '1983-04-25', 10, 'Memphis', 'PIT', 'Steelers_DeAngelo_Williams_34.jpg', '0'),
(68, 98, 'Williams, Vince', 'ILB', 'ACT', '6''1"', 253, '1989-12-27', 3, 'Florida State', 'PIT', 'Steelers_Vince_Williams_98.jpg', '0'),
(69, 56, 'Zumwalt, Jordan', 'OLB', 'RES', '6''4"', 235, '1991-10-13', 2, 'UCLA', 'PIT', 'Steelers_Jordan_Zumwalt_56.jpg', '0');

-- --------------------------------------------------------

--
-- Table structure for table `scores`
--

DROP TABLE IF EXISTS `scores`;
CREATE TABLE IF NOT EXISTS `scores` (
  `ID` int(11) NOT NULL,
  `Code` varchar(3) NOT NULL,
  `Date` date NOT NULL,
  `ScoreHome` int(11) NOT NULL,
  `OpponentCode` varchar(3) NOT NULL,
  `ScoreOpponent` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=291 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `scores`
--

INSERT INTO `scores` (`ID`, `Code`, `Date`, `ScoreHome`, `OpponentCode`, `ScoreOpponent`) VALUES
(1, 'NE', '2015-09-10', 28, 'PIT', 21),
(2, 'PIT', '2015-09-10', 21, 'NE', 28),
(3, 'JAC', '2015-09-13', 9, 'CAR', 20),
(4, 'CAR', '2015-09-13', 20, 'JAC', 9),
(5, 'NYJ', '2015-09-13', 31, 'CLE', 10),
(6, 'CLE', '2015-09-13', 10, 'NYJ', 31),
(7, 'CHI', '2015-09-13', 23, 'GB', 31),
(8, 'GB', '2015-09-13', 31, 'CHI', 23),
(9, 'BUF', '2015-09-13', 27, 'IND', 14),
(10, 'IND', '2015-09-13', 14, 'BUF', 27),
(11, 'HOU', '2015-09-13', 20, 'KC', 27),
(12, 'KC', '2015-09-13', 27, 'HOU', 20),
(13, 'WAS', '2015-09-13', 10, 'MIA', 17),
(14, 'MIA', '2015-09-13', 17, 'WAS', 10),
(15, 'STL', '2015-09-13', 34, 'SEA', 31),
(16, 'SEA', '2015-09-13', 31, 'STL', 34),
(17, 'SD', '2015-09-13', 33, 'DET', 28),
(18, 'DET', '2015-09-13', 28, 'SD', 33),
(19, 'ARI', '2015-09-13', 31, 'NO', 19),
(20, 'NO', '2015-09-13', 19, 'ARI', 31),
(21, 'DEN', '2015-09-13', 19, 'BAL', 13),
(22, 'BAL', '2015-09-13', 13, 'DEN', 19),
(23, 'OAK', '2015-09-13', 13, 'CIN', 33),
(24, 'CIN', '2015-09-13', 33, 'OAK', 13),
(25, 'TB', '2015-09-13', 14, 'TEN', 42),
(26, 'TEN', '2015-09-13', 42, 'TB', 14),
(27, 'DAL', '2015-09-13', 27, 'NYG', 26),
(28, 'NYG', '2015-09-13', 26, 'DAL', 27),
(29, 'ATL', '2015-09-14', 26, 'PHI', 24),
(30, 'PHI', '2015-09-14', 24, 'ATL', 26),
(31, 'SF', '2015-09-14', 20, 'MIN', 3),
(32, 'MIN', '2015-09-14', 3, 'SF', 20),
(33, 'KC', '2015-09-17', 24, 'DEN', 31),
(34, 'DEN', '2015-09-17', 31, 'KC', 24),
(35, 'CHI', '2015-09-20', 23, 'ARI', 48),
(36, 'ARI', '2015-09-20', 48, 'CHI', 23),
(37, 'NYG', '2015-09-20', 20, 'ATL', 24),
(38, 'ATL', '2015-09-20', 24, 'NYG', 20),
(39, 'MIN', '2015-09-20', 26, 'DET', 16),
(40, 'DET', '2015-09-20', 16, 'MIN', 26),
(41, 'CAR', '2015-09-20', 24, 'HOU', 17),
(42, 'HOU', '2015-09-20', 17, 'CAR', 24),
(43, 'BUF', '2015-09-20', 32, 'NE', 40),
(44, 'NE', '2015-09-20', 40, 'BUF', 32),
(45, 'CIN', '2015-09-20', 24, 'SD', 19),
(46, 'SD', '2015-09-20', 19, 'CIN', 24),
(47, 'PIT', '2015-09-20', 43, 'SF', 18),
(48, 'SF', '2015-09-20', 18, 'PIT', 43),
(49, 'WAS', '2015-09-20', 24, 'STL', 10),
(50, 'STL', '2015-09-20', 10, 'WAS', 24),
(51, 'NO', '2015-09-20', 19, 'TB', 26),
(52, 'TB', '2015-09-20', 26, 'NO', 19),
(53, 'CLE', '2015-09-20', 28, 'TEN', 14),
(54, 'TEN', '2015-09-20', 14, 'CLE', 28),
(55, 'OAK', '2015-09-20', 37, 'BAL', 33),
(56, 'BAL', '2015-09-20', 33, 'OAK', 37),
(57, 'JAC', '2015-09-20', 23, 'MIA', 20),
(58, 'MIA', '2015-09-20', 20, 'JAC', 23),
(59, 'PHI', '2015-09-20', 10, 'DAL', 20),
(60, 'DAL', '2015-09-20', 20, 'PHI', 10),
(61, 'GB', '2015-09-20', 27, 'SEA', 17),
(62, 'SEA', '2015-09-20', 17, 'GB', 27),
(63, 'IND', '2015-09-21', 7, 'NYJ', 20),
(64, 'NYJ', '2015-09-21', 20, 'IND', 7),
(65, 'NYG', '2015-09-24', 32, 'WAS', 21),
(66, 'WAS', '2015-09-24', 21, 'NYG', 32),
(67, 'DAL', '2015-09-27', 28, 'ATL', 39),
(68, 'ATL', '2015-09-27', 39, 'DAL', 28),
(69, 'BAL', '2015-09-27', 24, 'CIN', 28),
(70, 'CIN', '2015-09-27', 28, 'BAL', 24),
(71, 'TEN', '2015-09-27', 33, 'IND', 35),
(72, 'IND', '2015-09-27', 35, 'TEN', 33),
(73, 'NE', '2015-09-27', 51, 'JAC', 17),
(74, 'JAC', '2015-09-27', 17, 'NE', 51),
(75, 'CAR', '2015-09-27', 27, 'NO', 22),
(76, 'NO', '2015-09-27', 22, 'CAR', 27),
(77, 'CLE', '2015-09-27', 20, 'OAK', 27),
(78, 'OAK', '2015-09-27', 27, 'CLE', 20),
(79, 'NYJ', '2015-09-27', 17, 'PHI', 24),
(80, 'PHI', '2015-09-27', 24, 'NYJ', 17),
(81, 'STL', '2015-09-27', 6, 'PIT', 12),
(82, 'PIT', '2015-09-27', 12, 'STL', 6),
(83, 'MIN', '2015-09-27', 31, 'SD', 14),
(84, 'SD', '2015-09-27', 14, 'MIN', 31),
(85, 'HOU', '2015-09-27', 19, 'TB', 9),
(86, 'TB', '2015-09-27', 9, 'HOU', 19),
(87, 'ARI', '2015-09-27', 47, 'SF', 7),
(88, 'SF', '2015-09-27', 7, 'ARI', 47),
(89, 'MIA', '2015-09-27', 14, 'BUF', 41),
(90, 'BUF', '2015-09-27', 41, 'MIA', 14),
(91, 'SEA', '2015-09-27', 26, 'CHI', 0),
(92, 'CHI', '2015-09-27', 0, 'SEA', 26),
(93, 'DET', '2015-09-27', 12, 'DEN', 24),
(94, 'DEN', '2015-09-27', 24, 'DET', 12),
(95, 'GB', '2015-09-28', 38, 'KC', 28),
(96, 'KC', '2015-09-28', 28, 'GB', 38),
(97, 'PIT', '2015-10-01', 20, 'BAL', 23),
(98, 'BAL', '2015-10-01', 23, 'PIT', 20),
(99, 'MIA', '2015-10-04', 14, 'NYJ', 27),
(100, 'NYJ', '2015-10-04', 27, 'MIA', 14),
(101, 'TB', '2015-10-04', 23, 'CAR', 37),
(102, 'CAR', '2015-10-04', 37, 'TB', 23),
(103, 'ATL', '2015-10-04', 48, 'HOU', 21),
(104, 'HOU', '2015-10-04', 21, 'ATL', 48),
(105, 'IND', '2015-10-04', 16, 'JAC', 13),
(106, 'JAC', '2015-10-04', 13, 'IND', 16),
(107, 'CIN', '2015-10-04', 36, 'KC', 21),
(108, 'KC', '2015-10-04', 21, 'CIN', 36),
(109, 'BUF', '2015-10-04', 10, 'NYG', 24),
(110, 'NYG', '2015-10-04', 24, 'BUF', 10),
(111, 'CHI', '2015-10-04', 22, 'OAK', 20),
(112, 'OAK', '2015-10-04', 20, 'CHI', 22),
(113, 'WAS', '2015-10-04', 23, 'PHI', 20),
(114, 'PHI', '2015-10-04', 20, 'WAS', 23),
(115, 'SD', '2015-10-04', 30, 'CLE', 27),
(116, 'CLE', '2015-10-04', 27, 'SD', 30),
(117, 'SF', '2015-10-04', 3, 'GB', 17),
(118, 'GB', '2015-10-04', 17, 'SF', 3),
(119, 'DEN', '2015-10-04', 23, 'MIN', 20),
(120, 'MIN', '2015-10-04', 20, 'DEN', 23),
(121, 'ARI', '2015-10-04', 22, 'STL', 24),
(122, 'STL', '2015-10-04', 24, 'ARI', 22),
(123, 'NO', '2015-10-04', 26, 'DAL', 20),
(124, 'DAL', '2015-10-04', 20, 'NO', 26),
(125, 'SEA', '2015-10-05', 13, 'DET', 10),
(126, 'DET', '2015-10-05', 10, 'SEA', 13),
(127, 'HOU', '2015-10-08', 20, 'IND', 27),
(128, 'IND', '2015-10-08', 27, 'HOU', 20),
(129, 'TEN', '2015-10-11', 13, 'BUF', 14),
(130, 'BUF', '2015-10-11', 14, 'TEN', 13),
(131, 'KC', '2015-10-11', 17, 'CHI', 18),
(132, 'CHI', '2015-10-11', 18, 'KC', 17),
(133, 'BAL', '2015-10-11', 30, 'CLE', 33),
(134, 'CLE', '2015-10-11', 33, 'BAL', 30),
(135, 'TB', '2015-10-11', 38, 'JAC', 31),
(136, 'JAC', '2015-10-11', 31, 'TB', 38),
(137, 'PHI', '2015-10-11', 39, 'NO', 17),
(138, 'NO', '2015-10-11', 17, 'PHI', 39),
(139, 'CIN', '2015-10-11', 27, 'SEA', 24),
(140, 'SEA', '2015-10-11', 24, 'CIN', 27),
(141, 'GB', '2015-10-11', 24, 'STL', 10),
(142, 'STL', '2015-10-11', 10, 'GB', 24),
(143, 'ATL', '2015-10-11', 25, 'WAS', 19),
(144, 'WAS', '2015-10-11', 19, 'ATL', 25),
(145, 'DET', '2015-10-11', 17, 'ARI', 42),
(146, 'ARI', '2015-10-11', 42, 'DET', 17),
(147, 'OAK', '2015-10-11', 10, 'DEN', 16),
(148, 'DEN', '2015-10-11', 16, 'OAK', 10),
(149, 'DAL', '2015-10-11', 6, 'NE', 30),
(150, 'NE', '2015-10-11', 30, 'DAL', 6),
(151, 'NYG', '2015-10-11', 30, 'SF', 27),
(152, 'SF', '2015-10-11', 27, 'NYG', 30),
(153, 'SD', '2015-10-12', 20, 'PIT', 24),
(154, 'PIT', '2015-10-12', 24, 'SD', 20),
(155, 'NO', '2015-10-15', 31, 'ATL', 21),
(156, 'ATL', '2015-10-15', 21, 'NO', 31),
(157, 'PIT', '2015-10-18', 25, 'ARI', 13),
(158, 'ARI', '2015-10-18', 13, 'PIT', 25),
(159, 'DET', '2015-10-18', 37, 'CHI', 34),
(160, 'CHI', '2015-10-18', 34, 'DET', 37),
(161, 'BUF', '2015-10-18', 21, 'CIN', 34),
(162, 'CIN', '2015-10-18', 34, 'BUF', 21),
(163, 'CLE', '2015-10-18', 23, 'DEN', 26),
(164, 'DEN', '2015-10-18', 26, 'CLE', 23),
(165, 'JAC', '2015-10-18', 20, 'HOU', 31),
(166, 'HOU', '2015-10-18', 31, 'JAC', 20),
(167, 'MIN', '2015-10-18', 16, 'KC', 10),
(168, 'KC', '2015-10-18', 10, 'MIN', 16),
(169, 'TEN', '2015-10-18', 10, 'MIA', 38),
(170, 'MIA', '2015-10-18', 38, 'TEN', 10),
(171, 'NYJ', '2015-10-18', 34, 'WAS', 20),
(172, 'WAS', '2015-10-18', 20, 'NYJ', 34),
(173, 'SEA', '2015-10-18', 23, 'CAR', 27),
(174, 'CAR', '2015-10-18', 27, 'SEA', 23),
(175, 'SF', '2015-10-18', 25, 'BAL', 20),
(176, 'BAL', '2015-10-18', 20, 'SF', 25),
(177, 'GB', '2015-10-18', 27, 'SD', 20),
(178, 'SD', '2015-10-18', 20, 'GB', 27),
(179, 'IND', '2015-10-18', 27, 'NE', 34),
(180, 'NE', '2015-10-18', 34, 'IND', 27),
(181, 'PHI', '2015-10-19', 27, 'NYG', 7),
(182, 'NYG', '2015-10-19', 7, 'PHI', 27),
(183, 'SF', '2015-10-22', 3, 'SEA', 20),
(184, 'SEA', '2015-10-22', 20, 'SF', 3),
(185, 'JAC', '2015-10-25', 34, 'BUF', 31),
(186, 'BUF', '2015-10-25', 31, 'JAC', 34),
(187, 'TEN', '2015-10-25', 7, 'ATL', 10),
(188, 'ATL', '2015-10-25', 10, 'TEN', 7),
(189, 'STL', '2015-10-25', 24, 'CLE', 6),
(190, 'CLE', '2015-10-25', 6, 'STL', 24),
(191, 'MIA', '2015-10-25', 44, 'HOU', 26),
(192, 'HOU', '2015-10-25', 26, 'MIA', 44),
(193, 'DET', '2015-10-25', 19, 'MIN', 28),
(194, 'MIN', '2015-10-25', 28, 'DET', 19),
(195, 'IND', '2015-10-25', 21, 'NO', 27),
(196, 'NO', '2015-10-25', 27, 'IND', 21),
(197, 'NE', '2015-10-25', 30, 'NYJ', 23),
(198, 'NYJ', '2015-10-25', 23, 'NE', 30),
(199, 'KC', '2015-10-25', 23, 'PIT', 13),
(200, 'PIT', '2015-10-25', 13, 'KC', 23),
(201, 'WAS', '2015-10-25', 31, 'TB', 30),
(202, 'TB', '2015-10-25', 30, 'WAS', 31),
(203, 'SD', '2015-10-25', 29, 'OAK', 37),
(204, 'OAK', '2015-10-25', 37, 'SD', 29),
(205, 'NYG', '2015-10-25', 27, 'DAL', 20),
(206, 'DAL', '2015-10-25', 20, 'NYG', 27),
(207, 'CAR', '2015-10-25', 27, 'PHI', 16),
(208, 'PHI', '2015-10-25', 16, 'CAR', 27),
(209, 'ARI', '2015-10-26', 26, 'BAL', 18),
(210, 'BAL', '2015-10-26', 18, 'ARI', 26),
(211, 'NE', '2015-10-29', 36, 'MIA', 7),
(212, 'MIA', '2015-10-29', 7, 'NE', 36),
(213, 'KC', '2015-11-01', 45, 'DET', 10),
(214, 'DET', '2015-11-01', 10, 'KC', 45),
(215, 'CLE', '2015-11-01', 20, 'ARI', 34),
(216, 'ARI', '2015-11-01', 34, 'CLE', 20),
(217, 'PIT', '2015-11-01', 10, 'CIN', 16),
(218, 'CIN', '2015-11-01', 16, 'PIT', 10),
(219, 'CHI', '2015-11-01', 20, 'MIN', 23),
(220, 'MIN', '2015-11-01', 23, 'CHI', 20),
(221, 'NO', '2015-11-01', 52, 'NYG', 49),
(222, 'NYG', '2015-11-01', 49, 'NO', 52),
(223, 'BAL', '2015-11-01', 29, 'SD', 26),
(224, 'SD', '2015-11-01', 26, 'BAL', 29),
(225, 'STL', '2015-11-01', 27, 'SF', 6),
(226, 'SF', '2015-11-01', 6, 'STL', 27),
(227, 'ATL', '2015-11-01', 20, 'TB', 23),
(228, 'TB', '2015-11-01', 23, 'ATL', 20),
(229, 'HOU', '2015-11-01', 20, 'TEN', 6),
(230, 'TEN', '2015-11-01', 6, 'HOU', 20),
(231, 'OAK', '2015-11-01', 34, 'NYJ', 20),
(232, 'NYJ', '2015-11-01', 20, 'OAK', 34),
(233, 'DAL', '2015-11-01', 12, 'SEA', 13),
(234, 'SEA', '2015-11-01', 13, 'DAL', 12),
(235, 'DEN', '2015-11-01', 29, 'GB', 10),
(236, 'GB', '2015-11-01', 10, 'DEN', 29),
(237, 'CAR', '2015-11-02', 29, 'IND', 26),
(238, 'IND', '2015-11-02', 26, 'CAR', 29),
(239, 'CIN', '2015-11-05', 31, 'CLE', 10),
(240, 'CLE', '2015-11-05', 10, 'CIN', 31),
(241, 'CAR', '2015-11-08', 37, 'GB', 29),
(242, 'GB', '2015-11-08', 29, 'CAR', 37),
(243, 'NYJ', '2015-11-08', 28, 'JAC', 23),
(244, 'JAC', '2015-11-08', 23, 'NYJ', 28),
(245, 'BUF', '2015-11-08', 33, 'MIA', 17),
(246, 'MIA', '2015-11-08', 17, 'BUF', 33),
(247, 'PIT', '2015-11-08', 38, 'OAK', 35),
(248, 'OAK', '2015-11-08', 35, 'PIT', 38),
(249, 'MIN', '2015-11-08', 21, 'STL', 18),
(250, 'STL', '2015-11-08', 18, 'MIN', 21),
(251, 'NO', '2015-11-08', 28, 'TEN', 34),
(252, 'TEN', '2015-11-08', 34, 'NO', 28),
(253, 'NE', '2015-11-08', 27, 'WAS', 10),
(254, 'WAS', '2015-11-08', 10, 'NE', 27),
(255, 'SF', '2015-11-08', 17, 'ATL', 16),
(256, 'ATL', '2015-11-08', 16, 'SF', 17),
(257, 'TB', '2015-11-08', 18, 'NYG', 32),
(258, 'NYG', '2015-11-08', 32, 'TB', 18),
(259, 'IND', '2015-11-08', 27, 'DEN', 24),
(260, 'DEN', '2015-11-08', 24, 'IND', 27),
(261, 'DAL', '2015-11-08', 27, 'PHI', 33),
(262, 'PHI', '2015-11-08', 33, 'DAL', 27),
(263, 'SD', '2015-11-09', 19, 'CHI', 22),
(264, 'CHI', '2015-11-09', 22, 'SD', 19),
(265, 'NYJ', '2015-11-12', 17, 'BUF', 22),
(266, 'BUF', '2015-11-12', 22, 'NYJ', 17),
(267, 'TEN', '2015-11-15', 10, 'CAR', 27),
(268, 'CAR', '2015-11-15', 27, 'TEN', 10),
(269, 'STL', '2015-11-15', 13, 'CHI', 37),
(270, 'CHI', '2015-11-15', 37, 'STL', 13),
(271, 'PIT', '2015-11-15', 30, 'CLE', 9),
(272, 'CLE', '2015-11-15', 9, 'PIT', 30),
(273, 'TB', '2015-11-15', 10, 'DAL', 6),
(274, 'DAL', '2015-11-15', 6, 'TB', 10),
(275, 'GB', '2015-11-15', 16, 'DET', 18),
(276, 'DET', '2015-11-15', 18, 'GB', 16),
(277, 'BAL', '2015-11-15', 20, 'JAC', 22),
(278, 'JAC', '2015-11-15', 22, 'BAL', 20),
(279, 'PHI', '2015-11-15', 19, 'MIA', 20),
(280, 'MIA', '2015-11-15', 20, 'PHI', 19),
(281, 'WAS', '2015-11-15', 47, 'NO', 14),
(282, 'NO', '2015-11-15', 14, 'WAS', 47),
(283, 'OAK', '2015-11-15', 14, 'MIN', 30),
(284, 'MIN', '2015-11-15', 30, 'OAK', 14),
(285, 'DEN', '2015-11-15', 13, 'KC', 29),
(286, 'KC', '2015-11-15', 29, 'DEN', 13),
(287, 'NYG', '2015-11-15', 26, 'NE', 27),
(288, 'NE', '2015-11-15', 27, 'NYG', 26),
(289, 'SEA', '2015-11-15', 32, 'ARI', 39),
(290, 'ARI', '2015-11-15', 39, 'SEA', 32);

-- --------------------------------------------------------

--
-- Table structure for table `standings`
--

DROP TABLE IF EXISTS `standings`;
CREATE TABLE IF NOT EXISTS `standings` (
  `ID` int(11) NOT NULL,
  `Code` varchar(3) DEFAULT NULL,
  `TeamName` varchar(20) DEFAULT NULL,
  `W` int(11) DEFAULT NULL,
  `L` int(11) DEFAULT NULL,
  `T` bit(1) DEFAULT NULL,
  `Pct1` decimal(5,3) DEFAULT NULL,
  `PF` int(11) DEFAULT NULL,
  `PA` int(11) DEFAULT NULL,
  `Net_Pts` int(11) DEFAULT NULL,
  `TD` int(11) DEFAULT NULL,
  `Home` varchar(3) DEFAULT NULL,
  `Road` varchar(3) DEFAULT NULL,
  `Indiv` varchar(3) DEFAULT NULL,
  `Pct2` decimal(5,3) DEFAULT NULL,
  `Conf` varchar(3) DEFAULT NULL,
  `Pct3` decimal(5,3) DEFAULT NULL,
  `NonConf` varchar(3) DEFAULT NULL,
  `Streak` varchar(2) DEFAULT NULL,
  `Last_5` varchar(3) DEFAULT NULL,
  `Division` varchar(14) DEFAULT NULL,
  `Conference` varchar(50) DEFAULT NULL,
  `TeamLogo` varchar(100) NOT NULL,
  `SiteURL` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `standings`
--

INSERT INTO `standings` (`ID`, `Code`, `TeamName`, `W`, `L`, `T`, `Pct1`, `PF`, `PA`, `Net_Pts`, `TD`, `Home`, `Road`, `Indiv`, `Pct2`, `Conf`, `Pct3`, `NonConf`, `Streak`, `Last_5`, `Division`, `Conference`, `TeamLogo`, `SiteURL`) VALUES
(1, 'NE', 'New England Patriots', 9, 0, b'0', '33.667', 303, 169, 134, 31, '5-0', '3-0', '3-0', '1.000', '6-0', '1.000', '2-0', '8W', '5-0', 'ACE', 'AFC', 'patriots.jpg', ''),
(2, 'BUF', 'Buffalo Bills', 5, 4, b'0', '25.667', 231, 207, 24, 28, '2-3', '3-1', '3-1', '0.750', '5-3', '0.625', '0-1', '2W', '3-2', 'ACE', 'AFC', 'buffalos.jpg', ''),
(3, 'NYJ', 'New York Jets', 5, 4, b'0', '24.111', 217, 184, 33, 25, '3-2', '2-2', '1-2', '0.333', '4-3', '0.571', '1-1', '1L', '2-3', 'ACE', 'AFC', 'jets.jpg', ''),
(4, 'MIA', 'Miami Dolphins', 4, 5, b'0', '21.222', 191, 225, -34, 22, '1-2', '2-3', '0-4', '0.000', '2-5', '0.286', '1-0', '2L', '2-3', 'ACE', 'AFC', 'dolphins.jpg', ''),
(5, 'CIN', 'Cincinnati Bengals', 8, 0, b'0', '28.625', 229, 142, 87, 28, '4-0', '4-0', '3-0', '1.000', '7-0', '1.000', '1-0', '8W', '5-0', 'ACN', 'AFC', 'bengals.jpg', ''),
(6, 'PIT', 'Pittsburgh Steelers', 6, 4, b'0', '23.600', 236, 191, 45, 22, '3-2', '2-2', '0-2', '0.000', '2-4', '0.333', '3-0', '1W', '3-2', 'ACN', 'AFC', 'steelers.jpg', '/roster'),
(7, 'BAL', 'Baltimore Ravens', 2, 7, b'0', '23.333', 210, 236, -26, 19, '1-2', '1-4', '1-2', '0.333', '2-4', '0.333', '0-2', '1W', '2-3', 'ACN', 'AFC', 'ravens.jpg', ''),
(8, 'CLE', 'Cleveland Browns', 2, 8, b'0', '18.600', 186, 277, -91, 19, '1-3', '1-4', '1-1', '0.500', '2-5', '0.286', '0-2', '4L', '1-4', 'ACN', 'AFC', 'browns.jpg', ''),
(9, 'IND', 'Indianapolis Colts', 4, 5, b'0', '22.222', 200, 227, -27, 24, '2-3', '2-2', '3-0', '1.000', '4-3', '0.571', '0-2', '1W', '2-3', 'ACS', 'AFC', 'colts.jpg', ''),
(10, 'HOU', 'Houston Texans', 3, 5, b'0', '21.750', 174, 205, -31, 21, '2-2', '1-3', '2-1', '0.667', '2-3', '0.400', '1-2', '1W', '2-3', 'ACS', 'AFC', 'texans.jpg', ''),
(11, 'JAC', 'Jacksonville Jaguars', 3, 6, b'0', '21.333', 192, 255, -63, 20, '2-2', '0-4', '0-2', '0.000', '2-4', '0.333', '0-2', '1L', '1-4', 'ACS', 'AFC', 'jaguars.jpg', ''),
(12, 'TEN', 'Tennessee Titans', 2, 7, b'0', '18.778', 169, 214, -45, 19, '0-4', '2-2', '0-2', '0.000', '0-5', '0.000', '2-1', '1W', '1-4', 'ACS', 'AFC', 'titans.jpg', ''),
(13, 'DEN', 'Denver Broncos', 7, 2, b'0', '22.778', 205, 168, 37, 19, '3-0', '4-1', '2-0', '1.000', '4-1', '0.800', '3-0', '1L', '4-1', 'ACW', 'AFC', 'broncos.jpg', ''),
(14, 'OAK', 'Oakland Raiders', 4, 5, b'0', '25.222', 227, 241, -14, 25, '2-2', '2-2', '1-1', '0.500', '4-3', '0.571', '0-1', '1L', '2-3', 'ACW', 'AFC', 'raiders.jpg', ''),
(15, 'KC', 'Kansas City Chiefs', 4, 5, b'0', '24.889', 224, 195, 29, 21, '2-2', '1-3', '0-1', '0.000', '2-2', '0.500', '1-3', '2W', '2-3', 'ACW', 'AFC', 'chiefs.jpg', ''),
(16, 'SD', 'San Diego Chargers', 2, 7, b'0', '23.333', 210, 249, -39, 23, '2-3', '0-4', '0-1', '0.000', '1-4', '0.200', '1-3', '5L', '0-5', 'ACW', 'AFC', 'chargers.jpg', ''),
(17, 'NYG', 'New York Giants', 5, 5, b'0', '27.300', 273, 253, 20, 27, '3-1', '2-3', '2-2', '0.500', '4-4', '0.500', '1-0', '1W', '3-2', 'NCE', 'NFC', 'giants.jpg', ''),
(18, 'PHI', 'Philadelphia Eagles', 4, 5, b'0', '23.556', 212, 184, 28, 22, '2-1', '2-3', '2-2', '0.500', '3-4', '0.429', '1-0', '1W', '3-2', 'NCE', 'NFC', 'eagles.jpg', ''),
(19, 'WAS', 'Washington Redskins', 4, 5, b'0', '22.778', 205, 209, -4, 17, '3-1', '0-4', '1-1', '0.500', '3-2', '0.600', '0-3', '1L', '2-3', 'NCE', 'NFC', 'redskins.jpg', ''),
(20, 'DAL', 'Dallas Cowboys', 2, 7, b'0', '18.444', 166, 214, -48, 16, '1-4', '1-2', '2-2', '0.500', '2-5', '0.286', '0-1', '6L', '0-5', 'NCE', 'NFC', 'cowboys.jpg', ''),
(21, 'GB', 'Green Bay Packers', 6, 3, b'0', '24.333', 219, 185, 34, 24, '4-0', '2-2', '1-0', '1.000', '4-1', '0.800', '2-1', '2L', '3-2', 'NCN', 'NFC', 'packers.jpg', ''),
(22, 'MIN', 'Minnesota Vikings', 7, 2, b'0', '22.000', 198, 154, 44, 16, '4-0', '2-2', '3-0', '1.000', '4-1', '0.800', '2-1', '4W', '4-1', 'NCN', 'NFC', 'vikings.jpg', ''),
(23, 'CHI', 'Chicago Bears', 4, 5, b'0', '22.111', 199, 234, -35, 16, '1-3', '2-2', '0-3', '0.000', '0-5', '0.000', '3-0', '1W', '3-2', 'NCN', 'NFC', 'bears.jpg', ''),
(24, 'DET', 'Detroit Lions', 2, 7, b'0', '18.556', 167, 261, -94, 18, '1-3', '0-4', '1-2', '0.333', '1-4', '0.200', '0-3', '2L', '1-4', 'NCN', 'NFC', 'lions.jpg', ''),
(25, 'CAR', 'Carolina Panthers', 9, 0, b'0', '28.333', 255, 175, 80, 26, '5-0', '3-0', '2-0', '1.000', '5-0', '1.000', '3-0', '8W', '5-0', 'NCS', 'NFC', 'panthers.jpg', ''),
(26, 'ATL', 'Atlanta Falcons', 6, 3, b'0', '25.444', 229, 190, 39, 27, '3-1', '3-2', '0-2', '0.000', '4-3', '0.571', '2-0', '2L', '2-3', 'NCS', 'NFC', 'falcons.jpg', ''),
(27, 'NO', 'New Orleans Saints', 4, 6, b'0', '25.500', 255, 315, -60, 31, '3-2', '1-3', '1-2', '0.333', '3-4', '0.429', '1-1', '1L', '3-2', 'NCS', 'NFC', 'saints.jpg', ''),
(28, 'TB', 'Tampa Bay Buccaneers', 4, 5, b'0', '21.222', 191, 237, -46, 18, '1-3', '2-2', '2-1', '0.667', '2-3', '0.400', '1-2', '1L', '2-3', 'NCS', 'NFC', 'buccaneers.jpg', ''),
(29, 'ARI', 'Arizona Cardinals', 7, 2, b'0', '33.556', 302, 185, 117, 32, '3-1', '4-1', '2-1', '0.500', '5-1', '0.800', '2-1', '3W', '4-1', 'NCW', 'NFC', 'cardinals.jpg', ''),
(30, 'STL', 'St. Louis Rams', 4, 5, b'0', '18.444', 166, 183, -17, 16, '3-1', '4-1', '2-1', '1.000', '5-1', '0.500', '2-1', '3W', '4-1', 'NCW', 'NFC', 'rams.jpg', ''),
(31, 'SEA', 'Seattle Seahawks', 4, 5, b'0', '22.111', 199, 179, 20, 16, '2-1', '2-3', '1-1', '0.500', '4-3', '0.571', '0-1', '2W', '3-2', 'NCW', 'NFC', 'seahawks.jpg', ''),
(32, 'SF', 'San Francisco 49ers', 3, 6, b'0', '14.000', 126, 223, -97, 12, '3-2', '0-4', '0-3', '0.000', '2-5', '0.286', '1-1', '1W', '2-3', 'NCW', 'NFC', '49ers.jpg', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `roster`
--
ALTER TABLE `roster`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Code` (`Code`);

--
-- Indexes for table `scores`
--
ALTER TABLE `scores`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `standings`
--
ALTER TABLE `standings`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Code` (`Code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `roster`
--
ALTER TABLE `roster`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=70;
--
-- AUTO_INCREMENT for table `scores`
--
ALTER TABLE `scores`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=291;
--
-- AUTO_INCREMENT for table `standings`
--
ALTER TABLE `standings`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `roster`
--
ALTER TABLE `roster`
  ADD CONSTRAINT `FK_Code` FOREIGN KEY (`Code`) REFERENCES `standings` (`Code`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
